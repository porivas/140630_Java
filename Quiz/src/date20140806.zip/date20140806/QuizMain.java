package date20140806;


public class QuizMain {
	public static void main(String[] args) throws InterruptedException {
		
		new QuizStage();
	}
}
